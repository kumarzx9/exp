//
//  LoadingManager.swift
//  machineT
//
//  Created by kumar on 19/08/24.
//

import Foundation
import ProgressHUD

class LoadingManager {
    
    static let shared = LoadingManager()
    private init() {
        ProgressHUD.animationType = .circleStrokeSpin
    }
    
    func showLoading() {
        ProgressHUD.animate()
    }
    
    func hideLoading() {
        ProgressHUD.dismiss()
    }
}
