//
//  File.swift
//  machineT
//
//  Created by kumar on 19/08/24.
//

import Foundation

struct AnonnymousTruckListModal : Codable {
    let status : Bool?
    let code : Int?
    let data : [Data]?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case code = "code"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Bool.self, forKey: .status)
        code = try values.decodeIfPresent(Int.self, forKey: .code)
        data = try values.decodeIfPresent([Data].self, forKey: .data)
    }
    
    
    
    // MARK: Data
    struct Data : Codable {
        let id : Int?
        let name : String?
        let user_id : String?
        let map_logo : String?
        let truck_logo : String?
        let cuisine_id : String?
        let description : String?
        let address : String?
        let latitude : String?
        let longitude : String?
        let website_url : String?
        let online : String?
        let status : String?
        let crmb_url : String?
        let food_truck_slots_id : String?
        let food_truck_slots_food_truck_id : String?
        let food_truck_slots_latitude : String?
        let food_truck_slots_longitude : String?
        let food_truck_slots_check_in : String?
        let food_truck_slots_start_time : String?
        let food_truck_slots_end_time : String?
        let food_truck_slots_address : String?
        let food_truck_slots_date : String?
        let cnv_start_time : String?
        let cnv_end_time : String?
        let cnv_diff : String?
        let now : String?
        let last_open : String?
        let distance : String?
        let cnv_now_time : String?
        let is_follow : String?
        let same_loc_cnt : String?
        let is_future_slot : String?
        let followers_count : Int?
        let is_follow_by_me : Bool?
        let is_follow_by_me_new : Bool?
        let is_follow_by_customer : Bool?
        let rating_logo : String?
        let map_logo_thumbnail : String?
        let cuisines : Cuisines?
        let count_same_truck : Int?

        enum CodingKeys: String, CodingKey {

            case id = "id"
            case name = "name"
            case user_id = "user_id"
            case map_logo = "map_logo"
            case truck_logo = "truck_logo"
            case cuisine_id = "cuisine_id"
            case description = "description"
            case address = "address"
            case latitude = "latitude"
            case longitude = "longitude"
            case website_url = "website_url"
            case online = "online"
            case status = "status"
            case crmb_url = "crmb_url"
            case food_truck_slots_id = "food_truck_slots_id"
            case food_truck_slots_food_truck_id = "food_truck_slots_food_truck_id"
            case food_truck_slots_latitude = "food_truck_slots_latitude"
            case food_truck_slots_longitude = "food_truck_slots_longitude"
            case food_truck_slots_check_in = "food_truck_slots_check_in"
            case food_truck_slots_start_time = "food_truck_slots_start_time"
            case food_truck_slots_end_time = "food_truck_slots_end_time"
            case food_truck_slots_address = "food_truck_slots_address"
            case food_truck_slots_date = "food_truck_slots_date"
            case cnv_start_time = "cnv_start_time"
            case cnv_end_time = "cnv_end_time"
            case cnv_diff = "cnv_diff"
            case now = "now"
            case last_open = "last_open"
            case distance = "distance"
            case cnv_now_time = "cnv_now_time"
            case is_follow = "is_follow"
            case same_loc_cnt = "same_loc_cnt"
            case is_future_slot = "is_future_slot"
            case followers_count = "followers_count"
            case is_follow_by_me = "is_follow_by_me"
            case is_follow_by_me_new = "is_follow_by_me_new"
            case is_follow_by_customer = "is_follow_by_customer"
            case rating_logo = "rating_logo"
            case map_logo_thumbnail = "map_logo_thumbnail"
            case cuisines = "cuisines"
            case count_same_truck = "count_same_truck"
        }

        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            id = try values.decodeIfPresent(Int.self, forKey: .id)
            name = try values.decodeIfPresent(String.self, forKey: .name)
            user_id = try values.decodeIfPresent(String.self, forKey: .user_id)
            map_logo = try values.decodeIfPresent(String.self, forKey: .map_logo)
            truck_logo = try values.decodeIfPresent(String.self, forKey: .truck_logo)
            cuisine_id = try values.decodeIfPresent(String.self, forKey: .cuisine_id)
            description = try values.decodeIfPresent(String.self, forKey: .description)
            address = try values.decodeIfPresent(String.self, forKey: .address)
            latitude = try values.decodeIfPresent(String.self, forKey: .latitude)
            longitude = try values.decodeIfPresent(String.self, forKey: .longitude)
            website_url = try values.decodeIfPresent(String.self, forKey: .website_url)
            online = try values.decodeIfPresent(String.self, forKey: .online)
            status = try values.decodeIfPresent(String.self, forKey: .status)
            crmb_url = try values.decodeIfPresent(String.self, forKey: .crmb_url)
            food_truck_slots_id = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_id)
            food_truck_slots_food_truck_id = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_food_truck_id)
            food_truck_slots_latitude = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_latitude)
            food_truck_slots_longitude = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_longitude)
            food_truck_slots_check_in = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_check_in)
            food_truck_slots_start_time = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_start_time)
            food_truck_slots_end_time = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_end_time)
            food_truck_slots_address = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_address)
            food_truck_slots_date = try values.decodeIfPresent(String.self, forKey: .food_truck_slots_date)
            cnv_start_time = try values.decodeIfPresent(String.self, forKey: .cnv_start_time)
            cnv_end_time = try values.decodeIfPresent(String.self, forKey: .cnv_end_time)
            cnv_diff = try values.decodeIfPresent(String.self, forKey: .cnv_diff)
            now = try values.decodeIfPresent(String.self, forKey: .now)
            last_open = try values.decodeIfPresent(String.self, forKey: .last_open)
            distance = try values.decodeIfPresent(String.self, forKey: .distance)
            cnv_now_time = try values.decodeIfPresent(String.self, forKey: .cnv_now_time)
            is_follow = try values.decodeIfPresent(String.self, forKey: .is_follow)
            same_loc_cnt = try values.decodeIfPresent(String.self, forKey: .same_loc_cnt)
            is_future_slot = try values.decodeIfPresent(String.self, forKey: .is_future_slot)
            followers_count = try values.decodeIfPresent(Int.self, forKey: .followers_count)
            is_follow_by_me = try values.decodeIfPresent(Bool.self, forKey: .is_follow_by_me)
            is_follow_by_me_new = try values.decodeIfPresent(Bool.self, forKey: .is_follow_by_me_new)
            is_follow_by_customer = try values.decodeIfPresent(Bool.self, forKey: .is_follow_by_customer)
            rating_logo = try values.decodeIfPresent(String.self, forKey: .rating_logo)
            
            // default json4swift
            //map_logo_thumbnail = try values.decodeIfPresent(String.self, forKey: .map_logo_thumbnail)
            
            // method 1
            /*
            if let thumbnailString = try? values.decode(String.self, forKey: .map_logo_thumbnail) {
                map_logo_thumbnail = thumbnailString
             } else if let thumbnailNumber = try? values.decode(Int.self, forKey: .map_logo_thumbnail) {
                 map_logo_thumbnail = String(thumbnailNumber)
             } else {
                 map_logo_thumbnail = nil
             }
            */
            
            // method 2 by generic function
            map_logo_thumbnail = decodeString(values, forKey: .map_logo_thumbnail)
            
            cuisines = try values.decodeIfPresent(Cuisines.self, forKey: .cuisines)
            count_same_truck = try values.decodeIfPresent(Int.self, forKey: .count_same_truck)
        }

    }

    
    // MARK: cousines
    struct Cuisines : Codable {
        let id : Int?
        let name : String?
        let image : String?
        let status : String?
        let is_filter_by_me : Bool?

        enum CodingKeys: String, CodingKey {

            case id = "id"
            case name = "name"
            case image = "image"
            case status = "status"
            case is_filter_by_me = "is_filter_by_me"
        }

        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            id = try values.decodeIfPresent(Int.self, forKey: .id)
            name = try values.decodeIfPresent(String.self, forKey: .name)
            image = try values.decodeIfPresent(String.self, forKey: .image)
            status = try values.decodeIfPresent(String.self, forKey: .status)
            is_filter_by_me = try values.decodeIfPresent(Bool.self, forKey: .is_filter_by_me)
        }

    }
    

}


func decodeString<T>(_ container: KeyedDecodingContainer<T>, forKey key: T) -> String? where T: CodingKey {
    if let stringValue = try? container.decode(String.self, forKey: key) {
        return stringValue
    } else if let intValue = try? container.decode(Int.self, forKey: key) {
        return String(intValue)
    } else if let doubleValue = try? container.decode(Double.self, forKey: key) {
        return String(doubleValue)
    }
    return nil
}
