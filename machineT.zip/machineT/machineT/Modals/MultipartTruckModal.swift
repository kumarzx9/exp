//
//  MultipartTruckModal.swift
//  ApiDemo
//
//

import Foundation

struct MultipartTruckModal : Codable {
    let status : Bool?
    let code : Int?
    let data : MultipartTruckModalData?
    let error: String?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case code = "code"
        case data = "data"
        case error = "error"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Bool.self, forKey: .status)
        code = try values.decodeIfPresent(Int.self, forKey: .code)
        data = try values.decodeIfPresent(MultipartTruckModalData.self, forKey: .data)
        error = try values.decodeIfPresent(String.self, forKey: .error)
    }

    struct MultipartTruckModalData : Codable {
        let message : String?
        
        enum CodingKeys: String, CodingKey {
            
            case message = "message"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            message = try values.decodeIfPresent(String.self, forKey: .message)
        }
        
    }
}



        
        
    
