//
//  VideoUploadModal.swift
//  AngleDemo
//

//

import Foundation

struct VideoUploadModal: Decodable {
    let status: Bool?
    let code: Int?
    let data: VideoUploadModalDataClass?
    let error: String?
}

// MARK: - DataClass
struct VideoUploadModalDataClass: Decodable {
    let message: String?
    let video: String?
}
