//
//  ApiTry.swift
//  machineT
//
//  Created by kumar on 18/08/24.
//

import UIKit

class ApiVc: UIViewController {
    
    //MARK: IBOutlets
    @IBOutlet private weak var btnFirst: UIButton!
    @IBOutlet private weak var btnSecond: UIButton!
    @IBOutlet private weak var btnThird: UIButton!
    
    //MARK: Variables
    private let parms = [ApiParms.latitude: "40.76", ApiParms.longitude: "-111.89", ApiParms.timezone: "Asia/Kolkata"]
    private let anonymousFoodTruckListVM = AnonymousFoodTruckListVM()
    private let multipartTruckVM = MultipartTruckVM()
    
    //MARK: ViewLifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //MARK: IBActions
    // url session post(with common get and post method)
    @IBAction func didTapFirst(_ sender: UIButton) {
        foodTruckApi(parms: parms)
    }
    
    // alamofire post
    @IBAction func didTapSecond(_ sender: UIButton) {
        foodTruckApiAlamofire(parms: parms)
    }
    
    // url session
    @IBAction func didTapThird(_ sender: Any) {
        //createTruck()
        //singleVideoUpload()
    }
}

//--------------------------------------------

//MARK: Private Methods
private extension ApiVc {
    
    // url session post(with common get and post method)
    func foodTruckApi(parms: [String: Any]) {
        anonymousFoodTruckListVM.fetchRequest(parm: parms) { response in
            switch response {
            case .success(let data):
                print(data)
            case .failure(let error):
                print(error)
            }
        }
    }
    
    // Alamofire post
    func foodTruckApiAlamofire(parms: [String: Any]) {
        anonymousFoodTruckListVM.fetchData2(parms: parms) { response in
            switch response {
            case .success(let res):
                debugPrint(res)
            case .failure(let err):
                print(err)
            }
        }
    }
    
    // MARK: create truck url session chow
    func createTruck() {
        let param = ["cuisine_id": "45","name":"demno","description":"from demo","website_url":"","address":"Alaska, USA","latitude":"64.2008413","longitude":"-149.4936733"] as [String : Any]
        let imageArray = [UIImage(named: "Group 490")!, UIImage(named: "Group 491")!, UIImage(named: "Group 492")!]
        let mapLogoImage = UIImage(named: "rose")!
        let truckLogoImage = UIImage(named: "flower")!
        
        multipartTruckVM.mediaUpload(parms: param, singleMedia: ["map_logo": .image(mapLogoImage), "truck_logo": .image(truckLogoImage)], multipleImages: ["images[]": imageArray]) { response in
            switch response {
            case .success(let data):
                print(data)
            case .failure(let error):
                print(error)
            }
        }
    }
    
    // MARK: url Session single video upload golf
    func singleVideoUpload() {
        
        let videoURL = Bundle.main.url(forResource: "samplevid", withExtension: "mov")
        guard let imgVidData = try? Data(contentsOf: videoURL!) else {return}
        
        multipartTruckVM.videoUpload(singleMedia: ["video": .video(imgVidData)]) { response in
            switch response {
            case .success(let data):
                print(data)
            case .failure(let error):
                print(error)
            }
        }
    }
    
}
