//
//  SecCollectionViewCell.swift
//  machineT
//
//  Created by kumar on 18/08/24.
//

import UIKit

class SecCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
