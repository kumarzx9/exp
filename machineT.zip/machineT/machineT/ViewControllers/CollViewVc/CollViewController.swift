//
//  CollViewController.swift
//  machineT
//
//  Created by kumar on 18/08/24.
//

import UIKit

class CollViewController: UIViewController {

    @IBOutlet weak var collVw: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collVw.register(UINib(nibName: "SecCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "SecCollectionViewCell")
        collVw.dataSource = self
        collVw.delegate = self
        // Do any additional setup after loading the view.
    }
    

}

extension CollViewController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 9
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SecCollectionViewCell", for: indexPath) as! SecCollectionViewCell
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width/2-10, height: collectionView.frame.height/3-20)
    }
    
}
